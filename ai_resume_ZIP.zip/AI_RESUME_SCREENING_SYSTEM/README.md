
# AI Resume Screening System

## Project Description
An AI-powered Resume Screening System that analyzes resumes and compares them with a given job description.

## Features
- Accepts a job description
- Accepts multiple resumes
- Extracts text from PDF and DOCX resumes
- Extracts relevant skills
- Compares candidate skills with job requirements
- Uses TF-IDF and cosine similarity for NLP-based comparison
- Calculates a final matching score
- Ranks candidates based on relevance

## Technologies Used
- Python
- Pandas
- NumPy
- Scikit-learn
- PyPDF
- python-docx
- Google Colab

## How to Run
1. Open the AI_Resume_Screening_System.ipynb file in Google Colab.
2. Run the cells from top to bottom.
3. Enter or modify the job description.
4. Upload multiple PDF or DOCX resumes.
5. Run the remaining cells.
6. View the candidate ranking and matching scores.

## Output
The system produces a ranked list of candidates with:
- Skill Score
- NLP Similarity
- Final Match Score
- Matched Skills

## Conclusion
The system helps recruiters reduce manual resume screening effort and identify suitable candidates based on their relevance to a job description.
